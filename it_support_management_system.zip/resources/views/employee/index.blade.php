@extends('employee.master')

@section('title')
    Dashboard
@endsection

@section('page-title')
    Home
@endsection

@section('body')

<h3>Wellcome to BG IT Service and Solution</h3>

@endsection
