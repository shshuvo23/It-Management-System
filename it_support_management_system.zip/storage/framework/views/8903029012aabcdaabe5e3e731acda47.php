<?php $__env->startSection('title'); ?>
    Company
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-title'); ?>
    Add Company
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="row justify-content-center">
        <div class="col-10">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Company Added Form</h4>
                    <?php if(session('message')): ?>
                        <div class="alert alert-success">
                            <h4 style="text-align: center;"><?php echo e(session('message')); ?></h4>
                        </div>
                    <?php endif; ?>
                    <form action="<?php echo e(route('company.create')); ?>" method="post" class="m-t-40" novalidate>
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <h5>Company Name <span class="text-danger">*</span></h5>
                            <div class="controls">
                                <input type="text" name="company_name" class="form-control" required
                                    data-validation-required-message="This field is required">
                            </div>
                        </div>
                        <div class="text-xs-right">
                            <button type="submit" class="btn btn-info text-white">Add New Company</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End PAge Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\work\it_support_management_system\resources\views/admin/company/companyAdd.blade.php ENDPATH**/ ?>