<?php $__env->startSection('title'); ?>
    Engineer
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-title'); ?>
    Engineer List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <!-- table responsive -->
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">Engineer List </h4>
            <div class="table-responsive m-t-40">
                <table id="config-table" class="table display table-striped border no-wrap">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>User Name</th>
                            <th>E-mail</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $engineers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $engineer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($engineer->name); ?></td>
                                <td><?php echo e($engineer->email); ?></td>
                                <td>
                                    <?php if($engineer->usertype == 1): ?>
                                        <a href="" class="badge rounded-pill bg-info">Engineer</a>
                                    <?php elseif($engineer->usertype == 2): ?>
                                        <a href="" class="badge rounded-pill bg-info">Engineer Inactive</a>
                                    <?php else: ?>
                                        <a href="" class="badge rounded-pill bg-info">Admin</a>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <button class="btn btn-outline-primary waves-effect waves-light" type="button"><span
                                            class="btn-label"><i class=""></i></span>
                                        <a href="<?php echo e(route('engineer.status', ['id' => $engineer->id])); ?>">Change Status</a>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\work\it_support_management_system\resources\views/admin/engineer/engineerList.blade.php ENDPATH**/ ?>