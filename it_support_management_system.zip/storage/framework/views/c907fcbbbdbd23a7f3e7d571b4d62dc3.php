<?php $__env->startSection('title'); ?>
    Issue
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-title'); ?>
    Issue Add
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <!-- table responsive -->
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">Report List </h4>
            <div class="table-responsive m-t-40">
                <table id="config-table" class="table display table-striped border no-wrap">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Problem Title</th>
                            <th>Report Code</th>
                            <th>Problem Details</th>
                            <th>Report Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $issues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $issue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($issue->title->problem_title); ?></td>
                                <td><?php echo e($issue->issue_code); ?></td>
                                <td><?php echo $issue->description; ?></td>
                                <td>
                                    <?php if($issue->issue_status == 0): ?>
                                        <a href="" class="badge rounded-pill bg-info">Pending</a>
                                    <?php elseif($issue->issue_status == 1): ?>
                                        <a href="" class="badge rounded-pill bg-info">Working</a>
                                    <?php else: ?>
                                        <a href="" class="badge rounded-pill bg-info">Complete</a>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($issue->issue_status == 1): ?>
                                        <a href="<?php echo e(route('accessory.apporved', ['id' => $issue->id])); ?>"
                                            class="btn waves-effect waves-light btn-outline-info">Service
                                            Details</a>
                                    <?php elseif($issue->issue_status == 2): ?>
                                        <h3><span class="label label-success">Completed</span></h3>
                                        <?php if($issue->feedback->isNotEmpty()): ?>
                                            <?php if($issue->feedback->contains('status', 'Rejected')): ?>
                                                <a href="" class="badge rounded-pill bg-primary">Rejected Accessory</a>
                                            <?php else: ?>
                                                <a href="" class="badge rounded-pill bg-success">Approved Accessory</a>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <a href="" class="badge rounded-pill bg-info">NO accessories Used</a>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <h3><span class="label label-primary">Still Pending</span></h3>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('employee.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\work\it_support_management_system\resources\views/employee/issue/issueList.blade.php ENDPATH**/ ?>