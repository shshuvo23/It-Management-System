[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH F:\work\it_support_management_system\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>