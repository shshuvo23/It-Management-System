<?php $__env->startSection('title'); ?>
    Report
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-title'); ?>
    Task List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <!-- table responsive -->
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">Task List </h4>
            <?php if(session('message')): ?>
                <div class="alert alert-success">
                    <h4 style="text-align: center;"><?php echo e(session('message')); ?></h4>
                </div>
            <?php endif; ?>
            <div class="table-responsive m-t-40">
                <table id="config-table" class="table display table-striped border no-wrap">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>User Name</th>
                            <th>Schedule Date</th>
                            <th>Priority</th>
                            <th>Issue Code</th>
                            <th>User Company</th>
                            <th>User Department</th>
                            <th>User Designation</th>
                            <th>User Phone number</th>
                            <th>Working Status</th>
                            <th>Accessories Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($schedule->issue->employee->name); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($schedule->schedule_date)->format('d M Y')); ?></td>
                                <td>
                                    <?php if($schedule->priority === 'high'): ?>
                                        <span class="badge bg-primary"><?php echo e($schedule->priority); ?></span>
                                    <?php elseif($schedule->priority === 'medium'): ?>
                                        <span class="badge bg-success"><?php echo e($schedule->priority); ?></span>
                                    <?php elseif($schedule->priority === 'low'): ?>
                                        <span class="badge bg-info"><?php echo e($schedule->priority); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($schedule->issue->issue_code); ?></td>
                                <td><?php echo e($schedule->issue->employee->company->company_name); ?></td>
                                <td><?php echo e($schedule->issue->employee->department->department_name); ?></td>
                                <td><?php echo e($schedule->issue->employee->designation); ?></td>
                                <td><?php echo e($schedule->issue->employee->phone); ?></td>
                                <td>
                                    <?php if($schedule->issue->issue_status === 1): ?>
                                        <a href="<?php echo e(route('working.feedback', ['id' => $schedule->issue->id])); ?>"
                                            class="badge rounded-pill bg-info">Add Accessories</a>
                                    <?php else: ?>
                                        <?php if($schedule->issue->issue_status == 0): ?>
                                            <span class="label label-rounded label-primary">pending</span>
                                        <?php elseif($schedule->issue->issue_status == 2): ?>
                                            <span class="label label-rounded label-success">Completed</span>
                                        <?php else: ?>
                                            <span class="label label-rounded label-info">Working</span>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($schedule->feedback->isNotEmpty()): ?>
                                        <?php if($schedule->feedback->contains('status', 'Approved')): ?>
                                            <button type="button"
                                                class="btn waves-effect waves-light btn-rounded btn-outline-warning">Approved</button>
                                        <?php elseif($schedule->feedback->contains('status', 'Rejected')): ?>
                                            <button type="button"
                                                class="btn waves-effect waves-light btn-rounded btn-outline-danger">Rejected</button>
                                        <?php else: ?>
                                            <button type="button"
                                                class="btn waves-effect waves-light btn-rounded btn-outline-primary">Pending</button>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <a href="" class="badge rounded-pill bg-info">NO accessories Used</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\work\it_support_management_system\resources\views/engineer/report/taskList.blade.php ENDPATH**/ ?>