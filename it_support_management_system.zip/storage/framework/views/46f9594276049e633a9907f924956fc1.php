<?php $__env->startSection('title'); ?>
    Employee
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-title'); ?>
    Employee List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <!-- table responsive -->
    <div class="card">
        <div class="card-body">
            <?php if(session('message')): ?>
                <div class="alert alert-success">
                    <h4 style="text-align: center;"><?php echo e(session('message')); ?></h4>
                </div>
            <?php endif; ?>
            <h4 class="card-title">Employee List </h4>
            <div class="table-responsive m-t-40">
                <table id="config-table" class="table display table-striped border no-wrap">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>User Name</th>
                            <th>E-mail</th>
                            <th>Company</th>
                            <th>Department</th>
                            <th>Designation</th>
                            <th>Status</th>
                            <th>Phone Number</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($employee->id); ?></td>
                                <td><?php echo e($employee->name); ?></td>
                                <td><?php echo e($employee->email); ?></td>
                                <td><?php echo e($employee->company->company_name); ?></td>
                                <td><?php echo e($employee->department->department_name); ?></td>
                                <td><?php echo e($employee->designation); ?></td>
                                <td>
                                    <?php if($employee->status == 1): ?>
                                        <span class="label label-rounded label-primary">Active</span>
                                    <?php else: ?>
                                        <span class="label label-rounded label-warning">InActive</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($employee->phone); ?></td>
                                <td>


                                    <button class="btn btn-outline-primary waves-effect waves-light" type="button"><span
                                            class="btn-label"></span>
                                        <a href="<?php echo e(route('employee.status', ['id' => $employee->id])); ?>">Active</a>
                                    </button>
                                    
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\work\it_support_management_system\resources\views/admin/employee/employeeList.blade.php ENDPATH**/ ?>