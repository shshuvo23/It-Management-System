<?php $__env->startSection('title'); ?>
    Issue
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-title'); ?>
    Confirm Accessories
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card text-white bg-dark">
                <div class="card-header">
                    <h4 class="m-b-0 text-white">Used Accessories for Your Issue Please check carefully and Confirm</h4>
                </div>
                <div class="card-body">
                    <h4>Accessories Name</h4>
                    <?php if(count($accessoryData) > 0): ?>
                        <?php $__currentLoopData = $accessoryData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feedbackId => $accessories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <ol>
                                <?php $__currentLoopData = $accessories['accessory_names']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $accessoryName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($accessoryName); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ol>
                            <?php if($accessories['status'] == 'Pending'): ?>
                                <a href="<?php echo e(route('status.approve', ['id' => $feedbackId])); ?>"
                                    class="btn btn-primary text-white">Confirm Accessories</a>
                                <a href="<?php echo e(route('status.reject', ['id' => $feedbackId])); ?>"
                                    class="btn btn-primary text-white">Reject Accessories</a>
                            <?php endif; ?>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <p>No accessories found for this issue.</p>
                        <a href="<?php echo e(route('status.complete', ['id' => $issue->id])); ?>"
                            class="btn btn-primary text-white">Confirm</a>
                    <?php endif; ?>
                    
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('employee.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\work\it_support_management_system\resources\views/employee/issue/accessoryList.blade.php ENDPATH**/ ?>