<?php $__env->startSection('title'); ?>
    Report
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-title'); ?>
    pending Task List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <!-- table responsive -->
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">Pending List </h4>
            <div class="table-responsive m-t-40">
                <table id="config-table" class="table display table-striped border no-wrap">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>User Name</th>
                            <th>Problem Title</th>
                            <th>Report Code</th>
                            <th>Problem Details</th>
                            <th>User Company</th>
                            <th>User Department</th>
                            <th>User Designation</th>
                            <th>User Phone number</th>
                            <th>Report Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $pendings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pending): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($pending->employee->name); ?></td>
                                <td><?php echo e($pending->title->problem_title); ?></td>
                                <td><?php echo e($pending->issue_code); ?></td>
                                <td><?php echo $pending->description; ?></td>
                                <td><?php echo e($pending->employee->company->company_name); ?></td>
                                <td><?php echo e($pending->employee->department->department_name); ?></td>
                                <td><?php echo e($pending->employee->designation); ?></td>
                                <td><?php echo e($pending->employee->phone); ?></td>
                                <td>
                                    <?php if($pending->issue_status == 0): ?>
                                        <a href="" class="badge rounded-pill bg-info">Pending</a>
                                    <?php elseif($pending->issue_status == 1): ?>
                                        <a href="" class="badge rounded-pill bg-info">Working</a>
                                    <?php else: ?>
                                        <a href="" class="badge rounded-pill bg-info">Complete</a>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <button class="btn btn-outline-primary" type="button">
                                        <a href="<?php echo e(route('status.working', ['id' => $pending->id])); ?>">Change status for working</a>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\work\it_support_management_system\resources\views/engineer/report/pendingList.blade.php ENDPATH**/ ?>