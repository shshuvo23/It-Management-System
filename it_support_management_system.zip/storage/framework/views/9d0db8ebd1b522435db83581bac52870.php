<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-title'); ?>
    Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<h3>Wellcome to BG IT Service and Solution</h3>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('employee.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\work\it_support_management_system\resources\views/employee/index.blade.php ENDPATH**/ ?>