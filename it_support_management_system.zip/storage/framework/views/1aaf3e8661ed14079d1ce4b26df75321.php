<?php $__env->startSection('title'); ?>
    Report
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-title'); ?>
    Report List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <!-- table responsive -->
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">Report List </h4>
            <div class="table-responsive m-t-40">
                <table id="config-table" class="table display table-striped border no-wrap">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>User Name</th>
                            <th>Problem Title</th>
                            <th>Report Code</th>
                            <th>User Company</th>
                            <th>User Department</th>
                            <th>Contact no</th>
                            <th>User Designation</th>
                            <th>Problem Details</th>
                            <th>Report Status</th>
                            <th>Make Schedule</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($report->employee->name); ?></td>
                                <td><?php echo e($report->title->problem_title); ?></td>
                                <td><?php echo e($report->issue_code); ?></td>
                                <td><?php echo e($report->employee->company->company_name); ?></td>
                                <td><?php echo e($report->employee->department->department_name); ?></td>
                                <td><?php echo e($report->employee->phone); ?></td>
                                <td><?php echo e($report->employee->designation); ?></td>
                                <td><?php echo $report->description; ?></td>

                                <td>
                                    <?php if($report->issue_status == 0): ?>
                                        <a href="" class="badge rounded-pill bg-info">Pending</a>
                                    <?php elseif($report->issue_status == 1): ?>
                                        <a href="" class="badge rounded-pill bg-info">Working</a>
                                    <?php else: ?>
                                        <a href="" class="badge rounded-pill bg-info">Complete</a>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($report->makeSchedules->isEmpty()): ?>
                                        <!-- Show the "Schedule Date" button because there are no associated schedules -->
                                        <button class="btn btn-outline-primary waves-effect waves-light" type="button">
                                            <a href="<?php echo e(route('scheduledate.add', ['id' => $report->id])); ?>">Schedule
                                                Date</a>
                                        </button>
                                    <?php else: ?>
                                        <h5>Already Have Schedule Date</h5>
                                        <?php if($report->issue_status == 0): ?>
                                            <button class="btn btn-outline-primary waves-effect waves-light" type="button">
                                                <a href="<?php echo e(route('edit.schedule', ['id' => $report->id])); ?>">Edit Schedule
                                                    Date</a>
                                            </button>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\work\it_support_management_system\resources\views/admin/report/viewReport.blade.php ENDPATH**/ ?>