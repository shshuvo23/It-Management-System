<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('/')); ?>assets/assets/images/favicon.png">
    <title>Bg IT Department</title>
    <!-- This page CSS -->

    
    <link href="<?php echo e(asset('/')); ?>assets/assets/node_modules/morrisjs/morris.css" rel="stylesheet">
    <!--Toaster Popup message CSS -->
    
    <!-- Date picker plugins css -->
    <link
        href="<?php echo e(asset('/')); ?>assets/assets/node_modules/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css"
        rel="stylesheet">
    <link href="<?php echo e(asset('/')); ?>assets/assets/node_modules/bootstrap-datepicker/bootstrap-datepicker.min.css"
        rel="stylesheet" type="text/css" />

    <link rel="stylesheet" type="text/css"
        href="<?php echo e(asset('/')); ?>assets/assets/node_modules/datatables.net-bs4/css/dataTables.bootstrap4.css">
    <link rel="stylesheet" type="text/css"
        href="<?php echo e(asset('/')); ?>assets/assets/node_modules/datatables.net-bs4/css/responsive.dataTables.min.css">
    <!-- Custom CSS -->
    <link href="<?php echo e(asset('/')); ?>assets/dist/css/style.min.css" rel="stylesheet">
    <!-- Dashboard 1 Page CSS -->
    <link href="<?php echo e(asset('/')); ?>assets/dist/css/pages/dashboard1.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

<body class="skin-default fixed-layout">
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <div class="preloader">
        <div class="loader">
            <div class="loader__figure"></div>
            <p class="loader__label">Elite admin</p>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <header class="topbar">
            <nav class="navbar top-navbar navbar-expand-md navbar-dark">
                <!-- ============================================================== -->
                <!-- Logo -->
                <!-- ============================================================== -->
                <div class="navbar-header">
                    <a class="navbar-brand" href="index.html">
                        <!-- Logo icon --><b>
                            <!--You can put here icon as well // <i class="wi wi-sunset"></i> //-->
                            <!-- Dark Logo icon -->
                            
                            <!-- Light Logo icon -->
                            
                        </b>
                        <!--End Logo icon -->
                        <!-- Logo text --><span>
                            <!-- dark Logo text -->
                            
                            <!-- Light Logo text -->
                            
                </div>
                <!-- ============================================================== -->
                <!-- End Logo -->
                <!-- ============================================================== -->
                <div class="navbar-collapse">
                    <!-- ============================================================== -->
                    <!-- toggle and nav items -->
                    <!-- ============================================================== -->
                    <ul class="navbar-nav me-auto">
                        <!-- This is  -->
                        <li class="nav-item"> <a class="nav-link nav-toggler d-block d-md-none waves-effect waves-dark"
                                href="javascript:void(0)"><i class="ti-menu"></i></a> </li>
                        <li class="nav-item"> <a
                                class="nav-link sidebartoggler d-none d-lg-block d-md-block waves-effect waves-dark"
                                href="javascript:void(0)"><i class="icon-menu"></i></a> </li>
                        <!-- ============================================================== -->
                        <!-- Search -->
                        <!-- ============================================================== -->
                        <li class="nav-item">
                            <form class="app-search d-none d-md-block d-lg-block">
                                <input type="text" class="form-control" placeholder="Search & enter">
                            </form>
                        </li>
                    </ul>
                    <!-- ============================================================== -->
                    <!-- User profile and search -->
                    <!-- ============================================================== -->
                    
                </div>
            </nav>
        </header>
        <!-- ============================================================== -->
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <aside class="left-sidebar">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- User Profile-->
                <div class="user-profile">
                    <div class="user-pro-body">
                        <div>
                            <img src="<?php echo e(asset('/')); ?>assets/assets/images/users/user.png" alt="user-img"
                                class="img-circle">
                        </div>
                        <div class="dropdown">
                            <a href="javascript:void(0)" class="dropdown-toggle u-dropdown link hide-menu"
                                data-bs-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                <?php if(auth()->check()): ?>
                                    <?php if(auth()->user()->userType == 0): ?>
                                        <?php echo e(auth()->user()->name); ?>

                                    <?php elseif(auth()->user()->userType == 1): ?>
                                        <?php echo e(auth()->user()->name); ?>

                                    <?php endif; ?>
                                <?php endif; ?>
                                <span class="caret"></span>
                            </a>
                            
                            <div class="dropdown-menu animated flipInY">
                                <!-- text-->
                                <a href="<?php echo e(route('profile.show')); ?>" class="dropdown-item">
                                    <i class="ti-user"></i> My Profile</a>
                                <div class="dropdown-divider"></div>
                                <div class="dropdown-divider"></div>
                                <!-- text-->
                                <a href="" class="dropdown-item"
                                    onclick="event.preventDefault(); document.getElementById('logoutForm').submit();"><i
                                        class="fa fa-power-off"></i> Logout</a>
                                <form action="<?php echo e(route('logout')); ?>" method="POST" id="logoutForm">
                                    <?php echo csrf_field(); ?>
                                </form>
                                <!-- text-->
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                        <?php if(auth()->check()): ?>
                            <?php if(auth()->user()->usertype == 0): ?>
                                <!-- Admin -->
                                <li>
                                    <a class="waves-effect waves-dark" href="<?php echo e(route('dashboard')); ?>"
                                        aria-expanded="false">
                                        <i class="icon-speedometer"></i>
                                        <span class="hide-menu">Dashboard
                                        </span>
                                    </a>
                                </li>
                                <li>
                                    <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)"
                                        aria-expanded="false">
                                        <i class="ti-layout-grid2"></i>
                                        <span class="hide-menu">Users</span>
                                    </a>
                                    <ul aria-expanded="false" class="collapse">
                                        <li>
                                            <a href="<?php echo e(route('employee.add')); ?>">Add New Employee</a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('employee.list')); ?>">Employee List</a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('engineer.list')); ?>">Engineer List</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)"
                                        aria-expanded="false">
                                        <i class="ti-layout-grid2"></i>
                                        <span class="hide-menu">Company</span>
                                    </a>
                                    <ul aria-expanded="false" class="collapse">
                                        <li>
                                            <a href="<?php echo e(route('company.add')); ?>">Add New Company</a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('company.list')); ?>">Company List</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)"
                                        aria-expanded="false">
                                        <i class="ti-layout-grid2"></i>
                                        <span class="hide-menu">Department</span>
                                    </a>
                                    <ul aria-expanded="false" class="collapse">
                                        <li>
                                            <a href="<?php echo e(route('department.add')); ?>">Add New Department</a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('department.list')); ?>">Department List</a>
                                        </li>
                                    </ul>
                                </li>

                                <li>
                                    <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)"
                                        aria-expanded="false">
                                        <i class="ti-layout-grid2"></i>
                                        <span class="hide-menu">Title</span>
                                    </a>
                                    <ul aria-expanded="false" class="collapse">
                                        <li>
                                            <a href="<?php echo e(route('title.add')); ?>">Add New Title</a>
                                        </li>
                                        <li>
                                        <a href="<?php echo e(route('title.list')); ?>">Title List</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a class="waves-effect waves-dark" href="<?php echo e(route('view.report')); ?>"
                                        aria-expanded="false">
                                        <i class="icon-speedometer"></i>
                                        <span class="hide-menu">View Report List
                                        </span>
                                    </a>
                                </li>
                                <li>
                                    <a class="waves-effect waves-dark" href="<?php echo e(route('schedule.list')); ?>"
                                        aria-expanded="false">
                                        <i class="icon-speedometer"></i>
                                        <span class="hide-menu">View Schedule List
                                        </span>
                                    </a>
                                </li>
                                <li>
                                    <a class="waves-effect waves-dark" href="<?php echo e(route('complete.report')); ?>"
                                        aria-expanded="false">
                                        <i class="icon-speedometer"></i>
                                        <span class="hide-menu">View Completed Report List
                                        </span>
                                    </a>
                                </li>
                                <li class="nav-small-cap">--- SUPPORT</li>
                                <li>
                                    <a class="waves-effect waves-dark" href="" aria-expanded="false"
                                        onclick="event.preventDefault(); document.getElementById('logoutForm').submit();">
                                        <i class="far fa-circle text-success"></i>
                                        <span class="hide-menu">Log Out</span>
                                    </a>
                                    <form action="<?php echo e(route('logout')); ?>" method="POST" id="logoutForm">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </li>
                            <?php elseif(auth()->user()->usertype == 1): ?>
                                <!-- Admin -->
                                <li>
                                    <a class="waves-effect waves-dark" href="<?php echo e(route('dashboard')); ?>"
                                        aria-expanded="false">
                                        <i class="icon-speedometer"></i>
                                        <span class="hide-menu">Dashboard
                                        </span>
                                    </a>
                                </li>
                                <li>
                                    <a class="waves-effect waves-dark" href="<?php echo e(route('pending.report')); ?>"
                                        aria-expanded="false">
                                        <i class="icon-speedometer"></i>
                                        <span class="hide-menu">Pending Work List
                                        </span>
                                    </a>
                                </li>
                                <li>
                                    <a class="waves-effect waves-dark" href="<?php echo e(route('pending.task')); ?>"
                                        aria-expanded="false">
                                        <i class="icon-speedometer"></i>
                                        <span class="hide-menu">Task List
                                        </span>
                                    </a>
                                </li>
                                <li>
                                    <a class="waves-effect waves-dark" href="<?php echo e(route('complete.list')); ?>"
                                        aria-expanded="false">
                                        <i class="icon-speedometer"></i>
                                        <span class="hide-menu">Complete Task List
                                        </span>
                                    </a>
                                </li>
                                <li class="nav-small-cap">--- SUPPORT</li>
                                <li>
                                    <a class="waves-effect waves-dark" href="" aria-expanded="false"
                                        onclick="event.preventDefault(); document.getElementById('logoutForm').submit();">
                                        <i class="far fa-circle text-success"></i>
                                        <span class="hide-menu">Log Out</span>
                                    </a>
                                    <form action="<?php echo e(route('logout')); ?>" method="POST" id="logoutForm">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </li>
                            <?php endif; ?>
                        <?php endif; ?>
                        
                    </ul>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </aside>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-5 align-self-center">
                        <h4 class="text-themecolor"><?php echo $__env->yieldContent('title'); ?></h4>
                    </div>
                    <div class="col-md-7 align-self-center text-end">
                        <div class="d-flex justify-content-end align-items-center">
                            <ol class="breadcrumb justify-content-end">
                                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                                <li class="breadcrumb-item active"><?php echo $__env->yieldContent('page-title'); ?></li>
                            </ol>
                            
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Info box -->
                <!-- ============================================================== -->


                <?php echo $__env->yieldContent('body'); ?>



                <!-- ============================================================== -->
                <!-- End Page Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- footer -->
        <!-- ============================================================== -->
        <footer class="footer">
            © 2021 Eliteadmin by themedesigner.in
            <a href="https://www.wrappixel.com/">WrapPixel</a>
        </footer>
        <!-- ============================================================== -->
        <!-- End footer -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="<?php echo e(asset('/')); ?>assets/assets/node_modules/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="<?php echo e(asset('/')); ?>assets/assets/node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="<?php echo e(asset('/')); ?>assets/dist/js/perfect-scrollbar.jquery.min.js"></script>
    <!--Wave Effects -->
    <script src="<?php echo e(asset('/')); ?>assets/dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="<?php echo e(asset('/')); ?>assets/dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="<?php echo e(asset('/')); ?>assets/dist/js/custom.min.js"></script>
    <!-- ============================================================== -->
    <!-- This page plugins -->
    <!-- ============================================================== -->
    <!--morris JavaScript -->
    <script src="<?php echo e(asset('/')); ?>assets/assets/node_modules/raphael/raphael-min.js"></script>
    <script src="<?php echo e(asset('/')); ?>assets/assets/node_modules/morrisjs/morris.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>assets/assets/node_modules/sticky-kit-master/dist/sticky-kit.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>assets/assets/node_modules/jquery-sparkline/jquery.sparkline.min.js"></script>
    <!-- Popup message jquery -->
    
    <!-- Chart JS -->
    <script src="<?php echo e(asset('/')); ?>assets/dist/js/dashboard1.js"></script>
    
    <script src="<?php echo e(asset('/')); ?>assets/dist/js/pages/validation.js"></script>
    <!--This page plugins -->
    <script src="<?php echo e(asset('/')); ?>assets/assets/node_modules/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>assets/assets/node_modules/datatables.net-bs4/js/dataTables.responsive.min.js">
    </script>
    <!-- Plugin JavaScript -->
    <script src="<?php echo e(asset('/')); ?>assets/assets/node_modules/moment/moment.js"></script>
    <script
        src="<?php echo e(asset('/')); ?>assets/assets/node_modules/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js">
    </script>
    <!-- Date Picker Plugin JavaScript -->
    <script src="<?php echo e(asset('/')); ?>assets/assets/node_modules/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
    <!-- Date range Plugin JavaScript -->
    <script src="../assets/node_modules/timepicker/bootstrap-timepicker.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>assets/assets/node_modules/bootstrap-daterangepicker/daterangepicker.js"></script>
    <!-- start - This is for export functionality only -->
    <script src="<?php echo e(asset('/')); ?>assets/cdn.datatables.net/buttons/1.5.1/js/dataTables.buttons.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>assets/cdn.datatables.net/buttons/1.5.1/js/buttons.flash.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>assets/cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>assets/cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/pdfmake.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>assets/cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/vfs_fonts.js"></script>
    <script src="<?php echo e(asset('/')); ?>assets/cdn.datatables.net/buttons/1.5.1/js/buttons.html5.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>assets/cdn.datatables.net/buttons/1.5.1/js/buttons.print.min.js"></script>
    <!-- end - This is for export functionality only -->
    <script>
        $(function() {
            $('#myTable').DataTable();
            var table = $('#example').DataTable({
                "columnDefs": [{
                    "visible": false,
                    "targets": 2
                }],
                "order": [
                    [2, 'asc']
                ],
                "displayLength": 25,
                "drawCallback": function(settings) {
                    var api = this.api();
                    var rows = api.rows({
                        page: 'current'
                    }).nodes();
                    var last = null;
                    api.column(2, {
                        page: 'current'
                    }).data().each(function(group, i) {
                        if (last !== group) {
                            $(rows).eq(i).before('<tr class="group"><td colspan="5">' + group +
                                '</td></tr>');
                            last = group;
                        }
                    });
                }
            });
            // Order by the grouping
            $('#example tbody').on('click', 'tr.group', function() {
                var currentOrder = table.order()[0];
                if (currentOrder[0] === 2 && currentOrder[1] === 'asc') {
                    table.order([2, 'desc']).draw();
                } else {
                    table.order([2, 'asc']).draw();
                }
            });
            // responsive table
            $('#config-table').DataTable({
                responsive: true
            });
            $('#example23').DataTable({
                dom: 'Bfrtip',
                buttons: [
                    'copy', 'csv', 'excel', 'pdf', 'print'
                ]
            });
            $('.buttons-copy, .buttons-csv, .buttons-print, .buttons-pdf, .buttons-excel').addClass(
                'btn btn-primary me-1');
        });
    </script>

    <script>
        $(document).ready(function() {
            // Counter to track the number of added accessory fields
            var accessoryCounter = 1;

            // Function to add new accessory input fields
            function addAccessoryFields() {
                accessoryCounter++;
                var newFields = `
                    <div class="accessory-row" data-row="${accessoryCounter}">
                        <div class="row">
                            <div class="col-lg-6">
                                <label class="control-label mt-3">Accessories Name</label>
                                <div class="input-group">
                                    <input type="text" name="accessory_name[]" class="form-control" aria-label="Text input with checkbox">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <label class="control-label mt-3">Accessories Price</label>
                                <div class="input-group">
                                    <span class="input-group-text">৳</span>
                                    <span class="input-group-text">0.00</span>
                                    <input type="number" name="accessory_price[]" class="form-control" aria-label="Amount (to the nearest dollar)">
                                </div>
                            </div>

                        </div>
                        <div class="col-lg-2 mt-3">
                                <button type="button" class="btn btn-danger remove-accessory" data-row="${accessoryCounter}">Remove</button>
                        </div>
                    </div>
                `;
                $('#accessory-container').append(newFields);
            }

            // Add more accessory fields on "Add More" button click
            $('#add-accessory').click(function() {
                addAccessoryFields();
            });

            // Remove accessory fields on "Remove" button click
            $(document).on('click', '.remove-accessory', function() {
                var rowToRemove = $(this).data('row');
                $('.accessory-row[data-row="' + rowToRemove + '"]').remove();
            });
        });
    </script>


    <script>
        // MAterial Date picker
        $('#mdate').bootstrapMaterialDatePicker({
            weekStart: 0,
            time: false
        });
        $('#timepicker').bootstrapMaterialDatePicker({
            format: 'HH:mm',
            time: true,
            date: false
        });
        $('#date-format').bootstrapMaterialDatePicker({
            format: 'dddd DD MMMM YYYY - HH:mm'
        });

        $('#min-date').bootstrapMaterialDatePicker({
            format: 'DD/MM/YYYY HH:mm',
            minDate: new Date()
        });
        // Clock pickers
        $('#single-input').clockpicker({
            placement: 'bottom',
            align: 'left',
            autoclose: true,
            'default': 'now'
        });
        $('.clockpicker').clockpicker({
            donetext: 'Done',
        }).find('input').change(function() {
            console.log(this.value);
        });
        $('#check-minutes').click(function(e) {
            // Have to stop propagation here
            e.stopPropagation();
            input.clockpicker('show').clockpicker('toggleView', 'minutes');
        });
        if (/mobile/i.test(navigator.userAgent)) {
            $('input').prop('readOnly', true);
        }
        // Colorpicker
        $(".colorpicker").asColorPicker();
        $(".complex-colorpicker").asColorPicker({
            mode: 'complex'
        });
        $(".gradient-colorpicker").asColorPicker({
            mode: 'gradient'
        });
        // Date Picker
        jQuery('.mydatepicker, #datepicker').datepicker();
        jQuery('#datepicker-autoclose').datepicker({
            autoclose: true,
            todayHighlight: true
        });
        jQuery('#date-range').datepicker({
            toggleActive: true
        });
        jQuery('#datepicker-inline').datepicker({
            todayHighlight: true
        });

        // -------------------------------
        // Start Date Range Picker
        // -------------------------------

        // Basic Date Range Picker
        $('.daterange').daterangepicker();

        // Date & Time
        $('.datetime').daterangepicker({
            timePicker: true,
            timePickerIncrement: 30,
            locale: {
                format: 'MM/DD/YYYY h:mm A'
            }
        });

        //Calendars are not linked
        $('.timeseconds').daterangepicker({
            timePicker: true,
            timePickerIncrement: 30,
            timePicker24Hour: true,
            timePickerSeconds: true,
            locale: {
                format: 'MM-DD-YYYY h:mm:ss'
            }
        });

        // Single Date Range Picker
        $('.singledate').daterangepicker({
            singleDatePicker: true,
            showDropdowns: true
        });

        // Auto Apply Date Range
        $('.autoapply').daterangepicker({
            autoApply: true,
        });

        // Calendars are not linked
        $('.linkedCalendars').daterangepicker({
            linkedCalendars: false,
        });

        // Date Limit
        $('.dateLimit').daterangepicker({
            dateLimit: {
                days: 7
            },
        });

        // Show Dropdowns
        $('.showdropdowns').daterangepicker({
            showDropdowns: true,
        });

        // Show Week Numbers
        $('.showweeknumbers').daterangepicker({
            showWeekNumbers: true,
        });

        $('.dateranges').daterangepicker({
            ranges: {
                'Today': [moment(), moment()],
                'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                'This Month': [moment().startOf('month'), moment().endOf('month')],
                'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf(
                    'month')]
            }
        });

        // Always Show Calendar on Ranges
        $('.shawCalRanges').daterangepicker({
            ranges: {
                'Today': [moment(), moment()],
                'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                'This Month': [moment().startOf('month'), moment().endOf('month')],
                'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf(
                    'month')]
            },
            alwaysShowCalendars: true,
        });

        // Top of the form-control open alignment
        $('.drops').daterangepicker({
            drops: "up" // up/down
        });

        // Custom button options
        $('.buttonClass').daterangepicker({
            drops: "up",
            buttonClasses: "btn",
            applyClass: "btn-info",
            cancelClass: "btn-danger"
        });

        jQuery('#date-range').datepicker({
            toggleActive: true
        });
        jQuery('#datepicker-inline').datepicker({
            todayHighlight: true
        });

        // Daterange picker
        $('.input-daterange-datepicker').daterangepicker({
            buttonClasses: ['btn', 'btn-sm'],
            applyClass: 'btn-danger',
            cancelClass: 'btn-inverse'
        });
        $('.input-daterange-timepicker').daterangepicker({
            timePicker: true,
            format: 'MM/DD/YYYY h:mm A',
            timePickerIncrement: 30,
            timePicker12Hour: true,
            timePickerSeconds: false,
            buttonClasses: ['btn', 'btn-sm'],
            applyClass: 'btn-danger',
            cancelClass: 'btn-inverse'
        });
        $('.input-limit-datepicker').daterangepicker({
            format: 'MM/DD/YYYY',
            minDate: '06/01/2015',
            maxDate: '06/30/2015',
            buttonClasses: ['btn', 'btn-sm'],
            applyClass: 'btn-danger',
            cancelClass: 'btn-inverse',
            dateLimit: {
                days: 6
            }
        });
    </script>

    <script>
        ! function(window, document, $) {
            "use strict";
            $("input,select,textarea").not("[type=submit]").jqBootstrapValidation();
        }(window, document, jQuery);
    </script>
</body>

</html>
<?php /**PATH F:\work\it_support_management_system\resources\views/master/master.blade.php ENDPATH**/ ?>