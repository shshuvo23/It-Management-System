<?php $__env->startSection('title'); ?>
    Report
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-title'); ?>
    Report Detail
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Issue Code</th>
                                <th>Report Title</th>
                                <th>Report Detail</th>
                                <th>Working Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <th><?php echo e($report->issue_code); ?></th>
                                <th><?php echo e($report->title->problem_title); ?></th>
                                <th><?php echo $report->description; ?></th>
                                <th>
                                    <?php if($report->issue_status == 0): ?>
                                        <a href="" class="badge rounded-pill bg-info">Pending</a>
                                    <?php elseif($report->issue_status == 1): ?>
                                        <a href="" class="badge rounded-pill bg-info">Working</a>
                                    <?php else: ?>
                                        <a href="" class="badge rounded-pill bg-info">Complete</a>
                                    <?php endif; ?>
                                </th>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Used Accessories List for this report</h4>
                    <div class="table-responsive m-t-40">
                        <?php if(session('message')): ?>
                            <div class="alert alert-success">
                                <h4 style="text-align: center;"><?php echo e(session('message')); ?></h4>
                            </div>
                        <?php endif; ?>
                        <table id="example23" class="display nowrap table table-hover table-striped border" cellspacing="0"
                            width="100%">
                            <thead>
                                <tr>
                                    <th>id</th>
                                    <th>Accessories Name</th>
                                    <th>Price</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $accessoryData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feedbackId => $accessories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $accessories['accessory_names']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $accessoryName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($accessoryName); ?></td>
                                            <td class="fw-bold ">
                                                <?php echo e(number_format($accessories['accessory_prices'][$index], 0)); ?> /= ৳</td>
                                            <td><?php echo e($accessories['status']); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php $__currentLoopData = $accessoryData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feedbackId => $accessories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('report.status', ['id' => $feedbackId])); ?>"
                                class="btn btn-primary text-white">Change Accessories</a>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\work\it_support_management_system\resources\views/admin/report/reportDetail.blade.php ENDPATH**/ ?>